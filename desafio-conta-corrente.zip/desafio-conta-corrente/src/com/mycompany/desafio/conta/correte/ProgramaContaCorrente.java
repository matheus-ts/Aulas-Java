package com.mycompany.desafio.conta.correte;
//@ Author Matheus Candido da Silva

public class ProgramaContaCorrente {
    public static void main(String[] args) {
            ContaCorrente c1 = new ContaCorrente("Matheus",50.00);
            ContaCorrente c2 = new ContaCorrente("Maria",20.00);

        c1.depositar(10,07,2020,50.00);
        c1.depositar(20,07,2020,100.00);

        c1.sacar(25,12,2020,100.00);
        c1.exibirStatus();
        c2.depositar(10,07,2020,50.00);
        c2.depositar(20,07,2020,100.00);

        c2.sacar(25,12,2020,100.00);
        c2.exibirStatus();
    }
}
//@ Author Matheus Candido da Silva
