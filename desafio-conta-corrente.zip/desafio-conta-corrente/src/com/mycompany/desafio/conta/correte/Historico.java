package com.mycompany.desafio.conta.correte;

import java.util.List;

public class Historico {
    private String Tipo;
    private Double valor;
    private Integer dia;
    private Integer mes;
    private Integer ano;

    private List<Historico> transações; //Criando lista do historico


    public Historico( Integer dia, Integer mes, Integer ano, Double valor, String tipo) {

        this.valor = valor;
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
        this.Tipo = Tipo;
        this.transações = transações;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public Double getValor() {
        return valor;
    }



    public Integer getDia() {
        return dia;
    }

    public Integer getMes() {
        return mes;
    }

    public Integer getAno() {
        return ano;
    }

    @Override
    public String toString() {
        return "Historico{" +
                "Tipo='" + Tipo + '\'' +
                ", valor=" + valor +
                ", dia=" + dia +
                ", mes=" + mes +
                ", ano=" + ano +
                ", transações=" + transações +
                '}';
    }
}
