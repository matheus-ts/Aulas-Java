package com.mycompany.desafio.conta.correte;
//@ Author Matheus Candido da Silva

import java.util.ArrayList;
import java.util.List;

public class ContaCorrente {
    private String titular;
    private Double saldo;
    private List<Historico> ListaTransacoes = new ArrayList<>();

    public ContaCorrente(String titular, Double saldo) {
        this.titular = titular;
        this.saldo = saldo;
        this.ListaTransacoes = new ArrayList<>();
    }

    public void sacar(Integer dia,Integer mes, Integer ano, Double valor) {

        if (valor <= saldo) {
            saldo-=valor;
            ListaTransacoes.add(new Historico(dia,mes,ano,valor, "Saque"));
        } else{
            System.out.println("Você não possui saldo suficiente para completar essa transação");
        }

    }

    public void depositar(Integer dia,Integer mes, Integer ano, Double valor)
    {
        saldo+= valor;
        ListaTransacoes.add(new Historico(dia,mes,ano,valor,"Deposito"));
    }

    //Metodo para exibir  a conta

    public void exibirStatus(){
        System.out.println("---------------------------------");
        System.out.println("--------------Extrato------------");
        System.out.println("---------------------------------");

        System.out.println("Titular da conta: " + getTitular());
        System.out.println(String.format("Seu saldo é: R$ %.2f",getSaldo()));

        //For turbinado para exibir todo array da lista transações

        for (Historico ListaTransacoes : ListaTransacoes){

            System.out.println("---------------------------------");
            System.out.println("--------Extrato Transações-------");
            System.out.println("---------------------------------");
            System.out.println("Tipo de Transação : " + ListaTransacoes.getTipo());
            System.out.println(String.format("Valor da transação R$ %.2f",ListaTransacoes.getValor()));
            System.out.println(
                    String.format("Data:{ %d / %d /  %d }",
                            ListaTransacoes.getDia(),
                            ListaTransacoes.getMes(),
                            ListaTransacoes.getAno()));

        }
    }




    public String getTitular() {
        return titular;
    }

    public Double getSaldo() {
        return saldo;
    }

    public List<Historico> getListaTransacoes() {
        return ListaTransacoes;
    }

    @Override
    public String toString() {
        return "ContaCorrente{" +
                "titular='" + titular + '\'' +
                ", saldo=" + saldo +
                ", ListaTransacoes=" + ListaTransacoes +
                '}';
    }
}
//@ Author Matheus Candido da Silva
