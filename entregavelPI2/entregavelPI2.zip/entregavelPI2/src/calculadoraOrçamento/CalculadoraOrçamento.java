package calculadoraOrçamento;

import javax.swing.*;

public class CalculadoraOrçamento {
    private JPanel panel1;
    private JLabel buttonLabel;
}
